package com.springUsersLogin.springbootLogin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.springUsersLogin.springbootLogin.model.Game;
import com.springUsersLogin.springbootLogin.repository.gameRepository;

@Service
public class gameService
{
	@Autowired
	gameRepository gamerepo;
	
	
	public List<Game> getAllGames()
	{
		return gamerepo.findAll(Sort.by("gameName"));
	}
	
	public Game getGamebyGameName(String gName)
	{
		return gamerepo.findByGameName(gName);
	}
	
	public void updateGuestList(String teamname, String guestlist)
	{
		gamerepo.updateGuest(teamname, guestlist);
	}
	
	public void updateGameCount(String teamname, String count)
	{
		gamerepo.updateGuestCount(teamname, count);
	}
	public List<Game> addGame(Game data)
	{
		
		 gamerepo.save(data);
		 return gamerepo.findAll();
	}
	public boolean getByGameName(String gName)
	{
		boolean isThere = true;
		if(gamerepo.findByGameName(gName)==null)
		{
			isThere = false;
		}
		else
		{
			isThere = true;
		}
		
		return isThere;
	}
	
	public List<Game> addBulk(List<Game> data)
	{
		int dummy = 0;
		
		try {
			
			for(int i=0; i<data.size();i++)
			{
				dummy =i;
				gamerepo.save(data.get(i));
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Fail to add : "+data.get(dummy));
		}
		
		return gamerepo.findAll();
	}
	
	public Game getByHomeTeam(String hteam)
	{
		return gamerepo.findByHomeTeam(hteam);
	}
	public String deleteGameBygName(String gName) 
	{
		String res = "";
		if(gamerepo.deleteByGameName(gName) == 1)
		{
			res = gName +" is deleted Successful";
		}
		else
		{
			res = "Game named '"+gName+"' is NOT Found";
		}
		return res;
	
	}
	
	

}
