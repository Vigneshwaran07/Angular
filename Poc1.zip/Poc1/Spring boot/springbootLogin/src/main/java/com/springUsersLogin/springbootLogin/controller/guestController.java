package com.springUsersLogin.springbootLogin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springUsersLogin.springbootLogin.model.Guest;
import com.springUsersLogin.springbootLogin.service.guestService;

@RestController
@CrossOrigin
public class guestController {
	
	@Autowired
	guestService serviceobj;
	
	@GetMapping(value="/getAllGuest")
	private List<Guest>getAllguest()
	{
		return serviceobj.getAllGuest();
	}
	
	@PostMapping(value="/addManyGuest")
	private List<Guest> addbulkguest(@RequestBody List<Guest> data)
	{
		return serviceobj.addBulkGuest(data);
	}

}
