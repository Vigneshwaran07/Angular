package com.springUsersLogin.springbootLogin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springUsersLogin.springbootLogin.model.Guest;
import com.springUsersLogin.springbootLogin.repository.guestRepository;

@Service
public class guestService {
	
	@Autowired
	guestRepository guestrepo;
	
	public List<Guest> getAllGuest()
	{
		return guestrepo.findAll();
	}
	
	public List<Guest> addBulkGuest(List<Guest> data)
	{
		
		int dummy = 0;
		
		try {
			
			for(int i=0; i<data.size();i++)
			{
				dummy =i;
				guestrepo.save(data.get(i));
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Fail to add : "+data.get(dummy));
		}
		 return guestrepo.findAll();
	}

}
