package com.springUsersLogin.springbootLogin.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="game")
public class Game {
	
	
	
	@Column(name = "game_name",unique = true)
	private String gameName;
	
	@Column(name = "game_date")
	private String gameDate;
	
	@Column(name = "game_venue")
	private String gameVenue;
	
	@Id
	@Column(name = "home_team")
	private String homeTeam;
	
	@Column(name = "away_team")
	private String awayTeam;
	
	@Column(name = "number_of_guest")
	private String numberOfGuest;
	
	@Column(name = "guest_list")
	private String guestList;
	
	public Game( String gameName, String gameDate, String gameVenue, String homeTeam, String awayTeam,
			String numberOfGuest, String guestList) {
		super();
		this.gameName = gameName;
		this.gameDate = gameDate;
		this.gameVenue = gameVenue;
		this.homeTeam = homeTeam;
		this.awayTeam = awayTeam;
		this.numberOfGuest = numberOfGuest;
		this.guestList = guestList;
	}
	
	public Game()
	{
		
	}


	public String getGameName() {
		return gameName;
	}

	public String getGameDate() {
		return gameDate;
	}

	public String getGameVenue() {
		return gameVenue;
	}

	public String getHomeTeam() {
		return homeTeam;
	}

	public String getAwayTeam() {
		return awayTeam;
	}

	public String getNumberOfGuest() {
		return numberOfGuest;
	}

	public String getGuestList() {
		return guestList;
	}


	public void setGameName(String gameName) {
		this.gameName = gameName;
	}

	public void setGameDate(String gameDate) {
		this.gameDate = gameDate;
	}

	public void setGameVenue(String gameVenue) {
		this.gameVenue = gameVenue;
	}

	public void setHomeTeam(String homeTeam) {
		this.homeTeam = homeTeam;
	}

	public void setAwayTeam(String awayTeam) {
		this.awayTeam = awayTeam;
	}

	public void setNumberOfGuest(String numberOfGuest) {
		this.numberOfGuest = numberOfGuest;
	}

	public void setGuestList(String guestList) {
		this.guestList = guestList;
	}

	
	
	
	

}
