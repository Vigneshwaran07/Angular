package com.springUsersLogin.springbootLogin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springUsersLogin.springbootLogin.model.Login;
import com.springUsersLogin.springbootLogin.service.loginService;

@RestController
public class loginController
{
	@Autowired
	private loginService service;
	
	
	@PostMapping(path = "/registerUser")
	@CrossOrigin
	public Login addUser(@RequestBody final Login data) throws Exception
	{
		String tempmail = data.getEmail();
		if(tempmail != null && !"".equals(tempmail))
		{
			Login trash = service.fetchUserByEmail(tempmail);
			if(trash != null)
			{
				throw new Exception("User with "+tempmail+" Already Exists");
			}
			
		}
		return service.saveUser(data);
	}
	
	@CrossOrigin
	@GetMapping(value = "/getAll")
	public List<Login> getAllUsers()
	{
		return  service.getAll();
	}
	
	@CrossOrigin
	@PostMapping(value = "/login")
	public Login loginChecker(@RequestBody final Login data) throws Exception
	{
		String tempmail = data.getEmail();
		String temppass = data.getPassword();
		Login temp = null;
		if(tempmail!=null && temppass != null)
		{
			 temp = service.fetchUserByEmailAndPassword(tempmail, temppass);
		}
		if(temp == null)
		{
			throw new Exception("Wrong Username or Password");
		}
		
		return temp;
		
		
	}

}
