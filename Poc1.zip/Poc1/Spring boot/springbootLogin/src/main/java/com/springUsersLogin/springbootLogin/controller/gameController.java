package com.springUsersLogin.springbootLogin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springUsersLogin.springbootLogin.model.Game;
import com.springUsersLogin.springbootLogin.service.gameService;

@RestController
@CrossOrigin
public class gameController {

	
	@Autowired
	gameService serviceobj;
	
	@PostMapping(value = "/addGame")
	private List<Game> addGame(@RequestBody final Game data) throws Exception
	{
		List<Game> temp = null;
		if(serviceobj.getByGameName(data.getGameName()) == false)
		{
			temp = serviceobj.addGame(data);
		}
		else
		{
			throw new Exception("Game Name "+data.getGameName()+" is already taken");
		}
		return temp;
	}
	
	@PostMapping(value = "/getGame")
	private Game getGame(@RequestBody final String gName)
	{
		return serviceobj.getByHomeTeam(gName)	;
	}
	
	@GetMapping(value = "/getAllGames")
	private List<Game> getAllGame()
	{
		return serviceobj.getAllGames();
	}
	
	@PostMapping(value = "/deleteGame")
	private String deleteGame(@RequestBody final String gName)
	{
		 return serviceobj.deleteGameBygName(gName);
	}
	
	
	
	@PostMapping(value = "/updateGuest")
	private void updateguest(@RequestBody final Game data)
	{
		 serviceobj.updateGuestList(data.getHomeTeam(), data.getGuestList());
		 serviceobj.updateGameCount(data.getHomeTeam(), data.getNumberOfGuest());
	}
	
	@PostMapping(value = "/addManyGames")
	private List<Game> addManygames(@RequestBody final List<Game> data)
	{
		return serviceobj.addBulk(data);
	}
	
	
	
}
