package com.springUsersLogin.springbootLogin.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.springUsersLogin.springbootLogin.model.Game;

@Repository
@Transactional
public interface gameRepository extends JpaRepository<Game, String> {
	
	public Game findByGameName(String gameName);
	public Game findByHomeTeam(String homeTeam);
	
	@Modifying
	@Query(value = "delete from Game g where g.gameName = :gNamepara")
	public Integer deleteByGameName(@Param("gNamepara") String gNamepara);
	
	
	@Modifying
	@Query("update Game g set g.guestList = :glist WHERE g.homeTeam = :hteam")
    void updateGuest(@Param("hteam") String hteam, @Param("glist") String glist);
	
	@Modifying
	@Query("update Game g set g.numberOfGuest = :gcount WHERE g.homeTeam = :hteam")
    void updateGuestCount(@Param("hteam") String hteam, @Param("gcount") String gcount);
	
	


	


}
