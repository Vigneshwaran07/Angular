package com.springUsersLogin.springbootLogin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springUsersLogin.springbootLogin.model.Login;
import com.springUsersLogin.springbootLogin.repository.loginRepository;

@Service
public class loginService {
	
	@Autowired
	loginRepository loginobj;
	
	public Login saveUser(Login data)
	{
		return loginobj.save(data);
	}
	
	public Login fetchUserByEmail(String email)
	{
		return loginobj.findByEmail(email);
	}
	
	public Login fetchUserByEmailAndPassword(String email, String pass)
	{
		return loginobj.findByEmailAndPassword(email, pass);
	}
	
	public List<Login> getAll()
	{
		return loginobj.findAll();
	}

}
