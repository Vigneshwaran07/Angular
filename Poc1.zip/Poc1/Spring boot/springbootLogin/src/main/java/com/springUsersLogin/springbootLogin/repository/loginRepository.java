package com.springUsersLogin.springbootLogin.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springUsersLogin.springbootLogin.model.Login;

@Repository
@Transactional
public interface loginRepository extends JpaRepository<Login, Integer> {

	public Login findByEmail(String email);
	public Login findByEmailAndPassword(String email, String password);

}
