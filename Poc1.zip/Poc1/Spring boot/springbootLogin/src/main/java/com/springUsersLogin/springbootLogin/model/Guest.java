package com.springUsersLogin.springbootLogin.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="guest")
public class Guest {
	
	@Id
	@Column(name= "guest_name")
	private String guestname;

	public Guest(String guestname) {
		super();
		this.guestname = guestname;
	}
	
	public Guest()
	{
		
	}

	public String getGuestname() {
		return guestname;
	}

	public void setGuestname(String guestname) {
		this.guestname = guestname;
	}
	
	
	

}
