package com.springUsersLogin.springbootLogin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springUsersLogin.springbootLogin.model.Guest;

public interface guestRepository extends JpaRepository<Guest, String> {

}
