package com.springUsersLogin.springbootLogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
