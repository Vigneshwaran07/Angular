-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 23, 2020 at 04:08 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `game`
--

CREATE TABLE `game` (
  `away_team` varchar(255) DEFAULT NULL,
  `game_date` varchar(255) DEFAULT NULL,
  `game_name` varchar(255) DEFAULT NULL,
  `game_venue` varchar(255) DEFAULT NULL,
  `home_team` varchar(255) NOT NULL,
  `number_of_guest` varchar(255) DEFAULT '0',
  `guest_list` varchar(255) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `game`
--

INSERT INTO `game` (`away_team`, `game_date`, `game_name`, `game_venue`, `home_team`, `number_of_guest`, `guest_list`) VALUES
('away2', '2020-09-01T18:30:00.000Z', 'game2', 'venue2', 'home2', '3', 'Guest3,Guest2,Guest5'),
('away4', '2020-09-04T18:30:00.000Z', 'game4', 'venue4', 'home4', '2', 'Guest5,Guest1'),
('away5', '2020-09-06T18:30:00.000Z', 'game5', 'venue5', 'home5', '2', 'Guest6,Guest7'),
('away6', '2020-09-09T18:30:00.000Z', 'game6', 'venue6', 'home6', '2', 'Guest7,Guest2'),
('away7', '2020-09-01T18:30:00.000Z', 'game7', 'venue7', 'home7', '2', 'Guest7,Guest1'),
('away8', '2020-09-10T18:30:00.000Z', 'game8', 'venue8', 'home8', '3', 'Guest5,Guest9,Guest1'),
('aw1', '2020-09-10T18:30:00.000Z', 'viky1', 'ven1', 'vikyhome', '0', NULL),
('aw2', '2020-09-10T18:30:00.000Z', 'viky2', 'ven2', 'vikyhome2', '1', 'Guest1');

-- --------------------------------------------------------

--
-- Table structure for table `guest`
--

CREATE TABLE `guest` (
  `guest_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `guest`
--

INSERT INTO `guest` (`guest_name`) VALUES
('Guest1'),
('Guest10'),
('Guest2'),
('guest25'),
('Guest3'),
('Guest4'),
('Guest5'),
('Guest6'),
('Guest7'),
('Guest8'),
('Guest9');

-- --------------------------------------------------------

--
-- Table structure for table `hibernate_sequence`
--

CREATE TABLE `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hibernate_sequence`
--

INSERT INTO `hibernate_sequence` (`next_val`) VALUES
(3);

-- --------------------------------------------------------

--
-- Table structure for table `logintable`
--

CREATE TABLE `logintable` (
  `id` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logintable`
--

INSERT INTO `logintable` (`id`, `email`, `password`, `username`) VALUES
(1, 'viky@gmail.com', 'new', 'viky'),
(2, 'viky3@gmail.com', 'new', 'kira'),
(9, 'here@gmail.com', '123', 'viky');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `description`, `name`, `price`) VALUES
(1, 'here', 'kira', 200);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `game`
--
ALTER TABLE `game`
  ADD PRIMARY KEY (`home_team`);

--
-- Indexes for table `guest`
--
ALTER TABLE `guest`
  ADD PRIMARY KEY (`guest_name`);

--
-- Indexes for table `logintable`
--
ALTER TABLE `logintable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
