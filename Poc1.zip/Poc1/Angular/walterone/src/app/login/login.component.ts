import { User } from './../user';
import {  Router } from '@angular/router';
import { LoginService } from '../service/login.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  

  constructor(private _service : LoginService, private route : Router) { }

  ngOnInit(): void {
  }

  user = new User();
  msg = "";
 
  loginUser()
  {
    this._service.loginUserfromRemote(this.user).subscribe(
      data=>{
        console.log("data received");
        this._service.authenticate(this.user.email);
        this._service.islogin= true;
        this.route.navigate(['/home']);

      },
      error=>{
        console.log("Error occured");
        this._service.islogin= false;
        this.msg = "Please enter correct EmailId and Password";
      }
    )
  }
  

}
