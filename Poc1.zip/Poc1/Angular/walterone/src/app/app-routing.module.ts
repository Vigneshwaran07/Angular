import { HomeComponent } from './home/home.component';
import { AddgameComponent } from './addgame/addgame.component';
import { AuthGuardService } from './service/auth-guard.service';
import { LogoutComponent } from './logout/logout.component';
import { LoginComponent } from './login/login.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GuestselecterComponent } from './guestselecter/guestselecter.component';
import { AddguestComponent } from './addguest/addguest.component';


const routes: Routes = [
  {path:"login",component:LoginComponent},
  {path:"",component:LoginComponent},
  {path:"addgame", component:AddgameComponent, canActivate:[AuthGuardService]},
  {path:"logout", component:LogoutComponent, canActivate:[AuthGuardService]},
  {path:"home",component:HomeComponent, canActivate:[AuthGuardService]},
  {path:'guestselecter',component:GuestselecterComponent,canActivate:[AuthGuardService]},
  {path:'addGuest', component:AddguestComponent, canActivate:[AuthGuardService]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
