import { LoginService } from './service/login.service';
import { Component, OnInit, AfterContentChecked, ChangeDetectorRef } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, AfterContentChecked {

  title = 'walterone';
  isloginlocal :boolean;
  constructor(private ref: ChangeDetectorRef,public _service : LoginService)
  {
    
  }
  ngOnInit(){
    this.isloginlocal = this._service.isUserLoggedIn();
}
  ngAfterContentChecked()
   {
    this.ref.detectChanges();
  }
  
  
  
}
