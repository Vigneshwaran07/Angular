import { NotificationService } from './../service/notification.service';
import { GuestService } from './../service/guest.service';
import { map, take } from 'rxjs/operators';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { LoginService } from './../service/login.service';
import { AddgameComponent } from './../addgame/addgame.component';
import { GameService } from './../service/game.service';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { Component, OnInit, ViewChild, ChangeDetectorRef, AfterContentChecked, OnDestroy, ElementRef } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { MatSelect } from '@angular/material/select';
import { TableUtil } from "./tableUtil";
import * as XLSX from 'xlsx';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit{



 

  show : boolean = false;
   
  clickEventsubscription:Subscription;
  constructor(public notificationService : NotificationService,public guestService :GuestService,public loginService : LoginService,public gameService :GameService, public dialog : MatDialog, public route : Router)
   {
    this.clickEventsubscription =  this.gameService.getClickEvent().subscribe(()=>
    {

    })
   }

  listData : MatTableDataSource<any>;
  
  @ViewChild(MatPaginator) paginator : MatPaginator
  @ViewChild(MatSelect) matSelect: MatSelect;



  displayedColumns : string[] = ['gameName','gameDate','gameVenue', 'homeTeam','awayTeam','numberOfGuest'];
  filteredValues: MyFilter = { homeTeam: [] };
  positionFilter = new FormControl();

  gameList: string[] = [];
  selectedGame : string[] = []
  
  ngOnInit(): void 
  {
    
    this.gameService.getAllGamesFromRemote().subscribe(
      data =>{
        let array = data;
        this.listData = new MatTableDataSource(array);
        this.listData.paginator = this.paginator;
        this.gameList = this.getAllTeam();
        this.listData.filterPredicate = this.customFilterPredicate();

      });

    this.positionFilter.valueChanges.subscribe((positionFilterValue)        => {
      this.filteredValues['homeTeam'] = positionFilterValue;
      this.listData.filter = JSON.stringify(this.filteredValues);

      });
 
  }
  starter()
  {
    this.gameService.getAllGamesFromRemote().subscribe(
      data =>{
        let array = data;
        this.listData = new MatTableDataSource(array);
        this.listData.paginator = this.paginator;
        this.gameList = this.getAllTeam();
        this.listData.filterPredicate = this.customFilterPredicate();
      });
  }

  ngAfterViewInit()
  { 
    this.matSelect.openedChange.subscribe(opened => {
      if (opened) {
        this.matSelect.panel.nativeElement.addEventListener('mouseleave', () => {
          this.matSelect.close();
        })
      }
    })    
  }


  searchKey : string = "";


  onSearchClear()
  {
    this.searchKey = "";
    this.applyFilter();
  }

  applyFilter()
  {
    this.listData.filterPredicate = function(data, filter: string): boolean {
      return data.gameName.toLowerCase().includes(filter) || data.homeTeam.toLowerCase().includes(filter) ;
  };
    this.listData.filter = this.searchKey.trim().toLowerCase();
    this.listData.filterPredicate = this.customFilterPredicate();
    this.filteredValues['homeTeam'] =[];
  
  }
viky : any;
  onFileChange(ev) {
    let workBook = null;
    let jsonData = null;
    const reader = new FileReader();
    const file = ev.target.files[0];
    //console.log(ev.target.files[0].type);
    if(ev.target.files[0].type+"" !="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    {
      //console.log("error in file type"); 
      this.notificationService.error("Error in File type")
      return;
    }
    reader.onload = (event) => {
      const data = reader.result;
      workBook = XLSX.read(data, { type: 'binary' });
      jsonData = workBook.SheetNames.reduce((initial, name) => {
        const sheet = workBook.Sheets[name];
        initial[name] = XLSX.utils.sheet_to_json(sheet);
        return initial;
      }, {});
      this.viky = jsonData[Object.keys(jsonData)[0]]
      //console.log(jsonData[Object.keys(jsonData)[0]])
      this.gameService.addManyGames(jsonData[Object.keys(jsonData)[0]]).pipe(take(1)).subscribe(
        data=>{
          this.notificationService.success('Games file Uploaded Successfull');
          this.starter();
        },
        error=>{
          this.notificationService.error('Failed to load games file');
          this.starter();
        }
      );
      
    }
    reader.readAsBinaryString(file);
  }

  onFileChange2(ev) {
    let workBook = null;
    let jsonData = null;
    const reader = new FileReader();
    const file = ev.target.files[0];
    if(ev.target.files[0].type+"" !="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    {
      //console.log("error in file type"); 
      this.notificationService.error("Error in File type")
      return;
    }
    reader.onload = (event) => {
      const data = reader.result;
      workBook = XLSX.read(data, { type: 'binary' });
      jsonData = workBook.SheetNames.reduce((initial, name) => {
        const sheet = workBook.Sheets[name];
        initial[name] = XLSX.utils.sheet_to_json(sheet);
        return initial;
      }, {});
      this.viky = jsonData[Object.keys(jsonData)[0]]
      console.log(jsonData[Object.keys(jsonData)[0]])
      
      this.guestService.addBulkGuest(jsonData[Object.keys(jsonData)[0]]).pipe(take(1)).subscribe(
        data=>{
          this.notificationService.success('Guests file Uploaded Successfull');
          this.starter();
        },
        error=>{
          this.notificationService.error('Failed to load guests file');
          this.starter();
        }
      );
    }
    reader.readAsBinaryString(file);
  }

  onCreateGame()
  {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus=true;
    dialogConfig.width="55%";
    const dialogId =  this.dialog.open(AddgameComponent, dialogConfig);
    dialogId.afterClosed().subscribe(
      ()=>
      {
        this.starter();
      }
    )


  }

  exportGuest() 
  {
    this.guestService.getAllguestFromRemote().subscribe(
    data=>{
      
      TableUtil.exportArrayToExcel(data, "Guests");
    }
    );
    
  }

  onAddGuest()
  {
      this.route.navigate(['addGuest']);
  }
 

  clearFilters()
  {
    this.filteredValues['homeTeam'] =[];
    this.listData.filter = JSON.stringify(this.filteredValues);
    this.positionFilter.reset([]);
  }
  
  temp : string[] = []
   getAllTeam()
   {
     this.temp= [];
    
     for(const i in Object.keys(this.listData.data))
     {
      this.temp.push(this.listData.data[i]['homeTeam'])  
    }

    return this.temp;
  }

  customFilterPredicate() {
    return (data: dataElement, filter: string): boolean => {
      let searchString = JSON.parse(filter) as MyFilter;
      let isPositionAvailable = false;
      if(searchString.homeTeam != undefined)
      {
        if (searchString.homeTeam.length) {
          for (const d of searchString.homeTeam) {
            if (data.homeTeam.toString().trim() == d) {
              isPositionAvailable = true;
            }
          }
        } else {
          isPositionAvailable = true;
        }
      }
      
      return isPositionAvailable || data.gameName.trim().toLowerCase().indexOf(filter.trim().toLowerCase()) !== -1 ||data.homeTeam.trim().toLowerCase().indexOf(filter.trim().toLowerCase()) !== -1 ;
    }
  }

  
  
 
}
export interface MyFilter {
  homeTeam: string[],
  
}
export interface dataElement {
  gameName : string,
  gameDate:string,
  gameVenue:string,
   homeTeam :string,
   awayTeam:string,
   numberOfGuest:string
  
}
