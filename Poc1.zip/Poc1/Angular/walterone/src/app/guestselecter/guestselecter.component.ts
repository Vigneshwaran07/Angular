import { MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { NotificationService } from './../service/notification.service';
import { GameService } from './../service/game.service';
import { Observable } from 'rxjs';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { GuestService } from './../service/guest.service';
import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatChipInputEvent, MatChipList } from '@angular/material/chips';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatAutocompleteSelectedEvent, MatAutocompleteTrigger } from '@angular/material/autocomplete';
import { startWith, map, take } from 'rxjs/operators';
import {MAT_DIALOG_DATA} from '@angular/material/dialog';


@Component({
  selector: 'app-guestselecter',
  templateUrl: './guestselecter.component.html',
  styleUrls: ['./guestselecter.component.css']
})
export class GuestselecterComponent implements OnInit {

  public guests = [];

  isLoading = true;
  completeData : any;
   
  constructor(@Inject(MAT_DIALOG_DATA) public receiver: any,public  dialogRef : MatDialogRef<GuestselecterComponent>,public notificationService: NotificationService,public fb: FormBuilder, private guestService : GuestService, private gameService : GameService, public router : Router) {
    
   }


  public selectable = true;
  public removable = true;
  public addOnBlur = true;
  public userForm: FormGroup;
  public user: User={
    guests: []
  };
  tempString: string;
  templist = [];
  ngOnInit(): void {
    

    this.guestService.getAllguestFromRemote().subscribe(
      data=>{
        this.guests = data;
      }
    );

    //console.log(this.guestService.teamname);

      this.gameService.getGameByTeamName(this.receiver['teamname']).pipe(take(1)).subscribe(
        data=>{
          this.completeData =  JSON.parse(data)
          this.tempString = this.completeData.guestList;
          if(this.tempString)
          {

          
          let temparray = this.tempString.split(',');
          for (let i = 0; i < temparray.length; i++)
          {
            let t = {guestname : this.tempString.split(',')[i]}
            this.templist.push(t)
          }
          this.user.guests=this.templist;
          this.templist = []
          this.isLoading = false;
        }
        else{
          this.user.guests = []
          this.templist = []
          this.isLoading = false;

        }
        }
      );

    this.buildUserForm();
  }


  onClose()
  {
    
  this.completeData = [];
   this.user.guests = [];
    this.dialogRef.close();

  }

  public filteredGuest$: Observable<Guest[]>;
  @ViewChild('guestList') guestList: MatChipList;

  readonly separatorKeysCodes: number[] = [ENTER, COMMA];

  
  public hasError = (controlName: string, errorName: string) => {
    return this.userForm.controls[controlName].hasError(errorName);
  }

  public selectGuest(event: MatAutocompleteSelectedEvent): void {
    if (!event.option) {
      return;
    }

    const value = event.option.value;

    if (value && value instanceof Object && !this.user.guests.includes(value)) {
      this.user.guests.push(value);
      this.userForm.get('guests').setValue(this.user.guests);
      this.userForm.get('guestInput').setValue('');
    }
  }

  public addGuest(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    if ((value).trim()) {
      const matches = this.guests.filter(guest =>
        guest.guestname.toLowerCase() === value);
      const formValue = this.userForm.get('guests').value;
      const matchesNotYetSelected = formValue === null ? matches : matches.filter(x =>
        !(formValue.find(y => y.guestname === x.guestname)));
      if (matchesNotYetSelected.length === 1) {
        this.user.guests.push(matchesNotYetSelected[0]);
        
          this.userForm.get('guests').setValue(this.user.guests);
        this.userForm.get('guestInput').setValue('');
        
        
      }
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }
  }

  public remove(guest: Guest) {
    const index = this.user.guests.indexOf(guest);
    if (index >= 0) {
      this.user.guests.splice(index, 1);
      this.userForm.get('guests').setValue(this.user.guests);
      this.userForm.get('guestInput').setValue('');
    }
  }

  public submitForm(): void
  {
    let ans = '';
    const finalOut = []
    this.user.guests.forEach((value) => {
    if (!finalOut.some(x=> (x.guestname === value.guestname ))) 
   {
        finalOut.push(value)
    }
  });
    for(let i=0; i<finalOut.length;i++)
    {
      ans += finalOut[i]['guestname'];
      if(i != finalOut.length-1)
      {
        ans += ',';
      }
    }
    this.completeData['guestList'] = ans;
    this.completeData['numberOfGuest'] = finalOut.length+"";
    this.guestService.updateGuestList(this.completeData).subscribe(
      data=>{
        this.notificationService.success('Guest added successfully');
        this.onClose()
      }
    )

  }

  private buildUserForm(): void {
    this.userForm = this.fb.group({
      guestInput: [null],
      guests: [this.user.guests, this.validateGuests],
    });

    this.userForm.get('guests').statusChanges.subscribe(
      status => this.guestList.errorState = status === 'INVALID'
    );

    this.filteredGuest$ = this.userForm.get('guestInput').valueChanges
      .pipe(
        startWith(''),
        map(value => this.guestFilter(value))
      );
  }

  private guestFilter(value: any): Guest[] {
    const filterValue = (value === null || value instanceof Object) ? '' : value.toLowerCase();
    const matches = this.guests.filter(fruit =>
      fruit.guestname.toLowerCase().includes(filterValue));
    const formValue = this.userForm.get('guests').value;
    return formValue === null ? matches : matches.filter(x =>
      !(formValue.find(y => y.guestname === x.guestname))
    );
  }

  private validateGuests(guests: FormControl) {
    if (guests.value && guests.value.length === 0) {
      return {
        validateGuestArray: { valid: false }
      };
    }

    return null;
  }

}
export interface Guest {
  guestname: string;
}
export interface User {
  guests: Guest[];
}
