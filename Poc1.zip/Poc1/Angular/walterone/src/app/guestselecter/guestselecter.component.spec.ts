import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GuestselecterComponent } from './guestselecter.component';

describe('GuestselecterComponent', () => {
  let component: GuestselecterComponent;
  let fixture: ComponentFixture<GuestselecterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GuestselecterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GuestselecterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
