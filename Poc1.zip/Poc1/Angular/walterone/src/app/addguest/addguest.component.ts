import { GuestselecterComponent } from './../guestselecter/guestselecter.component';
import { Router } from '@angular/router';
import { GuestService } from './../service/guest.service';
import { GameService } from './../service/game.service';
import { Component, OnInit, ɵsetCurrentInjector } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { take } from 'rxjs/operators';
import { Location } from '@angular/common';

@Component({
  selector: 'app-addguest',
  templateUrl: './addguest.component.html',
  styleUrls: ['./addguest.component.css']
})
export class AddguestComponent implements OnInit {

  constructor(private location: Location,public dialog : MatDialog,private  gameService : GameService, public guestService : GuestService, private router : Router) { }

  games : any;
  ngOnInit(): void
  {
    this.gameService.getAllGamesFromRemote().subscribe(
      data=>{
        this.games = data;
      }
    )
}

  doStuff(teamname)
  {
    this.gameService.getGameByTeamName(teamname).pipe(take(1)).subscribe(
      data=>{
        let temp = JSON.parse(data);
       
        this.guestService.teamname = temp.homeTeam;
        const dialogConfig = new MatDialogConfig();
        dialogConfig.disableClose = true;
        dialogConfig.autoFocus=true;
        dialogConfig.width="60%";
        dialogConfig.data={teamname : temp.homeTeam};
        this.dialog.open(GuestselecterComponent, dialogConfig);

      }
    );

   
    
  }


  onBack() {
    this.location.back(); // <-- go back to previous location on cancel
  }



}
