import { Router } from '@angular/router';
import { NotificationService } from './../service/notification.service';
import { GameService } from './../service/game.service';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { DatePipe } from '@angular/common';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-addgame',
  templateUrl: './addgame.component.html',
  styleUrls: ['./addgame.component.css']
})
export class AddgameComponent implements OnInit {

  constructor(public gameService : GameService, public notificationService : NotificationService, private datePipe: DatePipe, public  dialogRef : MatDialogRef<AddgameComponent>, public router : Router) { }

  ngOnInit(): void {


  }

  onSubmit()
  {
    this.gameService.addGameToRemote(this.gameService.gameForm.value).subscribe(
      data=>{
        
        this.notificationService.success("Game Added Sucessfully");
        this.gameService.initializeForm();
        console.log("Game added");
        this.gameService.gameForm.reset();
        this.gameService.sendClickEvent();
        this.onClose();
        

      },
      error=>{
        this.gameService.gameForm.controls['gameName'].setErrors({"notUnique": true});
        this.notificationService.error("Game name already taken");
        console.log("Error in adding Game")
      }
    )

    
  }

  onClose()
  {
    this.gameService.gameForm.reset();
    this.gameService.initializeForm();
    this.dialogRef.close();
  }

}
