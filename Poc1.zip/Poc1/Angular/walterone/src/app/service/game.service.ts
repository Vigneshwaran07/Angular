import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {FormsModule, FormGroup, FormControl, Validators}  from '@angular/forms';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GameService  {

  constructor(private _http : HttpClient) { }

  gameForm : FormGroup = new FormGroup({
    gameName : new FormControl('', Validators.required),
    gameVenue : new FormControl('', Validators.required),
    homeTeam : new FormControl('', Validators.required),
    awayTeam : new FormControl('', Validators.required),
    gameDate : new FormControl('', Validators.required),
    numberOfGuest :new FormControl(0) 

  });

  filterForm : FormGroup = new FormGroup({
    selectedTeam : new FormControl(),
  })
  

  initializeForm()
  {
    this.gameForm.setValue({
      gameName :'',
      gameVenue :'',
      homeTeam :'',
      awayTeam : '',
      gameDate :'',
      numberOfGuest :0
    })
  }

  private subject = new Subject<any>();
  sendClickEvent()
  {
    this.subject.next();
  }
  getClickEvent(): Observable<any>
  { 
    return this.subject.asObservable();
  }

  

addGameToRemote(game):Observable<any>
{
  return this._http.post<any>('http://localhost:8080/addGame',game);

}
getAllGamesFromRemote():Observable<any>
{
  return this._http.get<any>('http://localhost:8080/getAllGames');
}

getGameByTeamName(teamname):Observable<any>
{
  return this._http.post<any>('http://localhost:8080/getGame', teamname,{ responseType: 'text' as 'json'  } )
}

addManyGames(bulk):Observable<any>
{
  console.log(bulk)
  return this._http.post<any>('http://localhost:8080/addManyGames', bulk)
}


}
