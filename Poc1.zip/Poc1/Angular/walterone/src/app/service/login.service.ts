import { User } from './../user';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private _http : HttpClient) { }
islogin = false;

  public loginUserfromRemote(user:User):Observable<any>
{
  return this._http.post<any>("http://localhost:8080/login",user );
}

authenticate(email : string)
{
  sessionStorage.setItem('email', email);
}

isUserLoggedIn() {
  let user = sessionStorage.getItem('email')
  return !(user === null)
}

logOut() {
  sessionStorage.removeItem('email');
  this.islogin = false;
  console.log('session removed');
}

}
