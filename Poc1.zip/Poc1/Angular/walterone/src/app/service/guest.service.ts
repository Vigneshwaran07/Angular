import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GuestService {

  constructor(private _http : HttpClient) { }

  teamname : string='home1';

  getAllguestFromRemote():Observable<any>
  {
    return this._http.get('http://localhost:8080/getAllGuest');
  }
  updateGuestList(data):Observable<any>
  {
    return this._http.post('http://localhost:8080/updateGuest',data);
  }

  addBulkGuest(data):Observable<any>
  {
    return this._http.post('http://localhost:8080/addManyGuest',data);
  }
}
