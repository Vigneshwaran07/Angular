Here 'walterone' is angular project (Poc1-- see root folder readme.md)

Get into project folder
Open Terminal
Run 'ng install'  ====> to install all ng modules
then ng serve to run