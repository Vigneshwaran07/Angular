Angular - contain angular project, run ng install before ng serve
springboot - backend rest api , import as maven project in eclipse ide
data - contain upload excel format (for Import option in webpage)(see 13-15 points in root readme)
sql - import sql file for database (data and structure of all tables)(use import option in phpmyadmin)